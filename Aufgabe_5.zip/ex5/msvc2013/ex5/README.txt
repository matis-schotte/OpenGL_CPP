Wie schon im Aufgabenblatt 4:
 * editieren Sie extlibs.props um die Pfadangaben zu den externen Bibliotheken korrekt zu setzen.
 * Nutzen Sie im Zweifelsfall das ZIP mit vorkompilierten Dateien das wir Ihnen f�r Aufgabenblatt 4 zur Verf�gung gestellt hatten.
 * Zus�tzlich benutzen wir in diesem Aufgabenblatt die Bibliothek GLEW. Diese wird �ber NuGet automatisch heruntergeladen und installiert
